﻿using UnityEngine;

public class PlatformSpawner : MonoBehaviour
{
    public GameObject platformPrefab; // 생성할 발판의 원본 프리팹
    public int count = 3; // 생성할 발판의 개수
    private GameObject healthPotionPrefab; // Platform 프리팹 내의 HP 회복 물약 오브젝트
    public int poolSize = 3; // 물약 풀 크기
    public float timeBetSpawnMin = 1.25f; // 다음 발판 배치까지의 시간 간격 최솟값
    public float timeBetSpawnMax = 2.25f; // 다음 발판 배치까지의 시간 간격 최댓값
    public float potionSpawnMin = 5f; // 다음 물약 스폰까지의 최소 시간 간격
    public float potionSpawnMax = 10f; // 다음 물약 스폰까지의 최대 시간 간격
    public float yMin = -3.5f; // 배치할 위치의 최소 y값
    public float yMax = 1.5f; // 배치할 위치의 최대 y값
    private float xPos = 20f; // 배치할 위치의 x 값

    private GameObject[] platforms; // 미리 생성한 발판들
    private int currentPlatformIndex = 0; // 사용할 현재 순번의 발판
    private GameObject[] potions; // 미리 생성한 물약들
    private int currentPotionIndex = 0; // 현재 사용할 물약 순번
    private float lastSpawnTime; // 마지막 발판 배치 시점
    private float lastPotionSpawnTime; // 마지막 물약 스폰 시점
    private float timeBetSpawn; // 다음 발판 배치까지의 시간 간격
    private float timeBetPotionSpawn; // 다음 물약 스폰까지의 시간 간격

    private Vector2 poolPosition = new Vector2(0, -25); // 초반에 생성된 오브젝트들을 숨길 위치
    private readonly string[] obstacleNames = { "Obstacle Left", "Obstacle Mid", "Obstacle Right" }; // 장애물 이름 배열

    void Start()
    {
        // 발판 풀 초기화
        platforms = new GameObject[count];
        for (int i = 0; i < count; i++)
        {
            platforms[i] = Instantiate(platformPrefab, poolPosition, Quaternion.identity);

            // Platform 프리팹 안에서 HealthPotion 오브젝트 찾기
            Transform healthPotionTransform = platforms[i].transform.Find("HealthPotion");
            if (healthPotionTransform != null)
            {
                healthPotionPrefab = healthPotionTransform.gameObject; // Platform 내의 HealthPotion 오브젝트 할당
                healthPotionPrefab.SetActive(false); // 초기 상태 비활성화
            }
            else
            {
                Debug.LogError("Platform 프리팹 내에 'HealthPotion' 오브젝트를 찾을 수 없습니다.");
            }
        }

        // 물약 풀 초기화
        potions = new GameObject[poolSize];
        for (int i = 0; i < poolSize; i++)
        {
            if (healthPotionPrefab != null)
            {
                potions[i] = healthPotionPrefab; // Platform 내에서 할당된 HealthPotion을 사용
                potions[i].SetActive(false); // 초기 상태 비활성화
            }
            else
            {
                Debug.LogError("healthPotionPrefab이 할당되지 않았습니다. Platform 프리팹 내에서 HealthPotion을 찾을 수 없습니다.");
            }
        }

        lastSpawnTime = 0f;
        lastPotionSpawnTime = 0f;
        timeBetSpawn = 0f;
        timeBetPotionSpawn = 0f;
    }

    void Update()
    {
        if (GameManager.instance.isGameover)
        {
            return;
        }

        // 발판 배치
        if (Time.time >= lastSpawnTime + timeBetSpawn)
        {
            lastSpawnTime = Time.time;
            timeBetSpawn = Random.Range(timeBetSpawnMin, timeBetSpawnMax);

            float yPos = Random.Range(yMin, yMax);

            platforms[currentPlatformIndex].SetActive(false);
            platforms[currentPlatformIndex].SetActive(true);

            platforms[currentPlatformIndex].transform.position = new Vector2(xPos, yPos);

            currentPlatformIndex++;
            if (currentPlatformIndex >= count)
            {
                currentPlatformIndex = 0;
            }
        }

        // 물약 스폰
        if (Time.time >= lastPotionSpawnTime + timeBetPotionSpawn)
        {
            lastPotionSpawnTime = Time.time;
            timeBetPotionSpawn = Random.Range(potionSpawnMin, potionSpawnMax);

            GameObject targetPlatform = platforms[currentPlatformIndex];

            if (targetPlatform != null && targetPlatform.activeInHierarchy) // null 체크 추가
            {
                // 랜덤으로 장애물 위치 선택 (Obstacle Left, Mid, Right)
                string selectedObstacle = obstacleNames[Random.Range(0, obstacleNames.Length)];
                Transform obstacleTransform = targetPlatform.transform.Find(selectedObstacle);

                // 장애물 이름을 찾을 수 없는 경우에 대한 추가 체크
                if (obstacleTransform == null)
                {
                    Debug.LogError($"장애물 '{selectedObstacle}'을 찾을 수 없습니다! 발판: {targetPlatform.name}");
                }

                Vector3 spawnPosition; // Vector3로 수정
                if (obstacleTransform != null)
                {
                    // 장애물 위치에 스폰 (장애물 위로 약간 올려서)
                    spawnPosition = new Vector3(obstacleTransform.position.x, obstacleTransform.position.y + 0.5f, 0f);
                    Debug.Log($"HP 회복 물약 스폰: 발판={targetPlatform.name}, 장애물={selectedObstacle}, 위치={spawnPosition}");
                }
                else
                {
                    // 장애물을 찾지 못한 경우 발판 중심에서 약간 위로 스폰
                    spawnPosition = targetPlatform.transform.position + new Vector3(0f, 1f, 0f);
                    Debug.LogWarning($"{targetPlatform.name}에서 {selectedObstacle}를 찾을 수 없어 기본 위치에 스폰합니다: 위치={spawnPosition}");
                }

                GameObject currentPotion = potions[currentPotionIndex];
                if (currentPotion != null)
                {
                    currentPotion.SetActive(false);
                    currentPotion.transform.SetParent(targetPlatform.transform, false);
                    currentPotion.transform.position = spawnPosition;
                    currentPotion.SetActive(true);
                }
                else
                {
                    Debug.LogError("물약이 파괴되었거나 비활성화된 상태입니다. 오브젝트 풀을 확인해주세요.");
                }

                currentPotionIndex++;
                if (currentPotionIndex >= poolSize)
                {
                    currentPotionIndex = 0;
                }
            }
            else
            {
                Debug.LogWarning("활성화된 발판을 찾을 수 없습니다. 발판 상태를 확인하세요.");
            }
        }
    }

    // platforms 배열에 접근할 수 있도록 메서드 (필요 시 유지)
    public GameObject[] GetPlatforms()
    {
        return platforms;
    }
}
